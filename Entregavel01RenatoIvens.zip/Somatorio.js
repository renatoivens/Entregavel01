var A = 50;
var B = 76;

var Soma = A + B;
document.write(Soma);
